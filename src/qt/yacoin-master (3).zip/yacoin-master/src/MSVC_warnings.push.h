// Copyright (c) 2009-2012 Bitcoin Developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifdef THE_BLUE_PILL                        
    // You take the blue pill � the story ends, you wake up in your bed and 
    // believe whatever you want to believe

    #ifdef THE_RED_PILL
        // You take the red pill � you stay in Wonderland, and I show you how 
        // deep the rabbit hole goes. Remember, all I'm offering is the truth � nothing more
        // [ at Warning level 3! ]
        #pragma warning( push )
    #else
        #include "MSVC_warnings.h"
    #endif
#endif